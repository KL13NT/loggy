module.exports = {
  purge: { content: ["./src/**/*.js", "./src/**/*.html", "./src/**/*.vue"] },
  theme: { extend: {} },
  variants: { extend: {} },
  plugins: [],
};
